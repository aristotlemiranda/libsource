CREATE DATABASE  IF NOT EXISTS `posdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `posdb`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: posdb
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inv_mgmt_category`
--

DROP TABLE IF EXISTS `inv_mgmt_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_mgmt_category` (
  `id` binary(16) NOT NULL,
  `category_name` varchar(50) DEFAULT NULL,
  `merchant_id` binary(16) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `arrangement` varchar(45) DEFAULT NULL,
  `created_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `modified_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `MERCHANT_ID_FK_idx` (`merchant_id`),
  CONSTRAINT `MERCHANT_ID_FK` FOREIGN KEY (`merchant_id`) REFERENCES `merchant` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_mgmt_category`
--

LOCK TABLES `inv_mgmt_category` WRITE;
/*!40000 ALTER TABLE `inv_mgmt_category` DISABLE KEYS */;
INSERT INTO `inv_mgmt_category` VALUES (_binary 'M)U1 \�\�B�\0','Pasta',_binary '\�\�_�1\�\�B�\0',NULL,'2','2024-06-23 05:18:45.397','2024-06-23 05:24:46.557'),(_binary '*�Y1 \�\�B�\0','Dessert',_binary '\�\�_�1\�\�B�\0',NULL,'3','2024-06-23 05:19:30.147','2024-06-23 05:24:46.560'),(_binary 'M\rd�1\�\�B�\0','Rice Meal',_binary '\�\�_�1\�\�B�\0',NULL,'1','2024-06-23 05:06:08.327','2024-06-23 05:24:46.555'),(_binary 'U(1 \�\�B�\0','Drinks',_binary '\�\�_�1\�\�B�\0',NULL,'4','2024-06-23 05:20:40.779','2024-06-23 05:24:46.562');
/*!40000 ALTER TABLE `inv_mgmt_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_mgmt_item`
--

DROP TABLE IF EXISTS `inv_mgmt_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_mgmt_item` (
  `id` binary(16) NOT NULL,
  `sku` varchar(100) NOT NULL,
  `item_name` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `bucket_name` varchar(250) NOT NULL,
  `sub_directory` varchar(500) NOT NULL,
  `category_id` binary(16) DEFAULT NULL,
  `merchant_id` binary(16) DEFAULT NULL,
  `created_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `modified_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku_UNIQUE` (`sku`),
  KEY `CATEGORY_ID_FK_idx` (`category_id`),
  KEY `MERCHANT_ID_FK2_idx` (`merchant_id`),
  CONSTRAINT `CATEGORY_ID_FK` FOREIGN KEY (`category_id`) REFERENCES `inv_mgmt_category` (`id`),
  CONSTRAINT `MERCHANT_ID_FK2` FOREIGN KEY (`merchant_id`) REFERENCES `merchant` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_mgmt_item`
--

LOCK TABLES `inv_mgmt_item` WRITE;
/*!40000 ALTER TABLE `inv_mgmt_item` DISABLE KEYS */;
INSERT INTO `inv_mgmt_item` VALUES (_binary 'T�1#\�\�B�\0','JAP-PASTA1','pasta_1.jpg','Pasta Special 1',11.50,'savorygo','pasta',_binary 'M)U1 \�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:42:07.670','2024-07-01 02:57:37.702'),(_binary 'W$0�1#\�\�B�\0','JAP-PASTA2','pasta_2.jpg','Pasta Special 2',17.50,'savorygo','pasta',_binary 'M)U1 \�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:42:12.737','2024-07-01 02:57:37.704'),(_binary 'W�i\�1#\�\�B�\0','JAP-PASTA3','pasta_3.jpg','Pasta Special 3',14.00,'savorygo','pasta',_binary 'M)U1 \�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:42:14.135','2024-07-01 02:57:37.705'),(_binary 'X\�\\x1#\�\�B�\0','JAP-PASTA4','pasta_4.jpg','Pasta Special 4',15.00,'savorygo','pasta',_binary 'M)U1 \�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:42:15.517','2024-07-01 02:57:37.707'),(_binary '^\Z�s1#\�\�B�\0','JAP-PASTA5','pasta_5.jpg','Pasta Special 5',12.50,'savorygo','pasta',_binary 'M)U1 \�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:42:24.418','2024-07-01 02:57:37.708'),(_binary 't\�9�1$\�\�B�\0','JAP-DANGO1','dango.jpg','Mitarashi Dango',4.50,'savorygo','dessert',_binary '*�Y1 \�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:50:11.950','2024-07-01 02:57:37.710'),(_binary 'z}�1$\�\�B�\0','JAP-MOCHI1','mochi.jpg','Sakura Mochi',0.10,'savorygo','dessert',_binary '*�Y1 \�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:50:20.878','2024-08-26 08:42:34.480'),(_binary '|\�O21$\�\�B�\0','JAP-AZUKI-BEAN1','red_bean.jpg','Azuki Red Bean',2.50,'savorygo','dessert',_binary '*�Y1 \�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:50:25.575','2024-07-01 02:57:37.713'),(_binary '��с1$\�\�B�\0','JAP-SFCAKE1','souffle_pancake.jpg','Souffle Pancake',7.50,'savorygo','dessert',_binary '*�Y1 \�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:50:41.864','2024-07-01 02:57:37.715'),(_binary '�C21$\�\�B�\0','JAP-SPCAKE1','sponge_cake.jpg','Matcha Sponge Cake',6.50,'savorygo','dessert',_binary '*�Y1 \�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:50:49.679','2024-07-01 02:57:37.716'),(_binary '\�\�1\�\�B�\0','JAP-BENTOBOX1','bento_box1.jpg','Bento Box Set 1',12.50,'savorygo','rice_meal',_binary 'M\rd�1\�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:10:11.620','2024-07-01 02:57:37.718'),(_binary '\�D\��1\�\�B�\0','JAP-BENTOBOX2','bento_box2.jpg','Bento Box Set 2',14.50,'savorygo','rice_meal',_binary 'M\rd�1\�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:10:37.126','2024-07-01 02:57:37.719'),(_binary '\��1\�\�B�\0','JAP-BENTOBOX3','bento_box3.jpg','Bento Box Set 3',15.50,'savorygo','rice_meal',_binary 'M\rd�1\�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:10:38.488','2024-07-01 02:57:37.721'),(_binary '\�cG1\�\�B�\0','JAP-BENTOBOX4','bento_box4.jpg','Bento Box Set 4',9.50,'savorygo','rice_meal',_binary 'M\rd�1\�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:10:39.535','2024-07-01 02:57:37.722'),(_binary '�1\�\�B�\0','JAP-BENTOBOX5','bento_box5.jpg','Bento Box Set 5',10.50,'savorygo','rice_meal',_binary 'M\rd�1\�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:10:40.906','2024-07-01 02:57:37.724'),(_binary '��\�1\�\�B�\0','JAP-BENTOBOX6','bento_box6.jpg','Bento Box Set 6',22.50,'savorygo','rice_meal',_binary 'M\rd�1\�\�B�\0',_binary '\�\�_�1\�\�B�\0','2024-06-23 05:10:42.900','2024-07-01 02:57:37.725');
/*!40000 ALTER TABLE `inv_mgmt_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `merchant`
--

DROP TABLE IF EXISTS `merchant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `merchant` (
  `id` binary(16) NOT NULL,
  `merchant_name` varchar(50) DEFAULT NULL,
  `account_id` varchar(45) DEFAULT NULL,
  `created_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `modified_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchant`
--

LOCK TABLES `merchant` WRITE;
/*!40000 ALTER TABLE `merchant` DISABLE KEYS */;
INSERT INTO `merchant` VALUES (_binary '\���\��O�����\�)�k','John\'s Updated Store','acc456','2024-08-20 14:31:07.303','2024-08-20 14:34:43.451'),(_binary '�S�\� BÄ�e�Mʂ�','John\'s Store','acc123','2024-08-20 15:30:52.303','2024-08-20 15:30:52.303'),(_binary '\�\�_�1\�\�B�\0','SavoryGO','001NPOS24','2024-06-23 04:27:31.033','2024-06-23 08:16:47.020'),(_binary '�\�H\�1\�\�B�\0','IceIceBaby','002NPOS24','2024-06-23 04:27:47.803','2024-06-23 08:16:47.022');
/*!40000 ALTER TABLE `merchant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partitional`
--

DROP TABLE IF EXISTS `partitional`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partitional` (
  `id` binary(16) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `created_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `created_year` int GENERATED ALWAYS AS (year(`created_date`)) STORED NOT NULL,
  `modify_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`,`created_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
/*!50100 PARTITION BY RANGE (`created_year`)
(PARTITION p2023 VALUES LESS THAN (2024) ENGINE = InnoDB,
 PARTITION p2024 VALUES LESS THAN (2025) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partitional`
--

LOCK TABLES `partitional` WRITE;
/*!40000 ALTER TABLE `partitional` DISABLE KEYS */;
INSERT INTO `partitional` (`id`, `name`, `created_date`, `modify_date`) VALUES (_binary 'y�\�8\�㮝B�\0','Alice','2023-01-15 10:00:00.000','2023-01-15 10:00:00.000'),(_binary 'yBZ8\�㮝B�\0','Bob','2023-07-20 15:30:00.000','2023-07-20 15:30:00.000'),(_binary 'yE�8\�㮝B�\0','Charlie','2024-03-05 09:45:00.000','2024-03-05 09:45:00.000');
/*!40000 ALTER TABLE `partitional` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion` (
  `id` binary(16) NOT NULL,
  `promotion_name` varchar(50) DEFAULT NULL,
  `created_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `modified_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion`
--

LOCK TABLES `promotion` WRITE;
/*!40000 ALTER TABLE `promotion` DISABLE KEYS */;
INSERT INTO `promotion` VALUES (_binary '\�>��7S\�zB�\0','Percentage Discounts','2024-07-01 02:43:55.247','2024-07-01 02:43:55.247'),(_binary '\�Jt�7S\�zB�\0','Dollars Off','2024-07-01 02:44:17.134','2024-07-01 02:44:17.134'),(_binary '\�*}7S\�zB�\0','Buy One Get One Free','2024-07-01 02:44:28.510','2024-07-01 02:44:28.510'),(_binary '\�\'G\�7S\�zB�\0','Buy 2 Get One Free of *item','2024-07-01 02:44:53.814','2024-07-01 02:45:37.734');
/*!40000 ALTER TABLE `promotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_promotion`
--

DROP TABLE IF EXISTS `sales_promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_promotion` (
  `id` binary(16) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `merchant_id` binary(16) NOT NULL,
  `promotion_id` binary(16) DEFAULT NULL,
  `promo_type` varchar(100) DEFAULT NULL,
  `discount_rate` decimal(10,0) DEFAULT NULL,
  `minus_off` decimal(10,0) DEFAULT NULL,
  `get_one_free` tinyint(1) DEFAULT NULL,
  `sku_free_item` varchar(100) DEFAULT NULL,
  `valid_from` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `valid_until` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `created_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `modified_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `PROMO_ID_FK_idx` (`promotion_id`),
  KEY `PROMO_MERCHANT_ID_FK_idx` (`merchant_id`),
  KEY `PROMO_SKU_FK_idx` (`sku`),
  CONSTRAINT `PROMO_ID_FK` FOREIGN KEY (`promotion_id`) REFERENCES `promotion` (`id`),
  CONSTRAINT `PROMO_MERCHANT_ID_FK` FOREIGN KEY (`merchant_id`) REFERENCES `merchant` (`id`),
  CONSTRAINT `PROMO_SKU_FK` FOREIGN KEY (`sku`) REFERENCES `inv_mgmt_item` (`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_promotion`
--

LOCK TABLES `sales_promotion` WRITE;
/*!40000 ALTER TABLE `sales_promotion` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_promotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `simple`
--

DROP TABLE IF EXISTS `simple`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `simple` (
  `id` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `amount` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `simple`
--

LOCK TABLES `simple` WRITE;
/*!40000 ALTER TABLE `simple` DISABLE KEYS */;
INSERT INTO `simple` VALUES (1,'First Record',10.00),(2,'Apple',20.00),(3,'Apple',30.00),(4,'Banana',40.00),(5,'Durian',50.00),(6,'Pineapple',60.00),(7,'Grape',70.00);
/*!40000 ALTER TABLE `simple` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock` (
  `sku` varchar(100) NOT NULL,
  `name` varchar(250) NOT NULL,
  `current_stock` int DEFAULT NULL,
  `reorder_level` int DEFAULT NULL,
  `reorder_quantity` int DEFAULT NULL,
  `last_restock_date` timestamp(3) NULL DEFAULT NULL,
  `expiration_date` timestamp(3) NULL DEFAULT NULL,
  `merchant_id` binary(16) DEFAULT NULL,
  `created_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
  `modified_date` timestamp(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `id` int NOT NULL,
  PRIMARY KEY (`sku`,`id`),
  KEY `STOCK_MERCHANT_ID_FK_idx` (`merchant_id`),
  CONSTRAINT `STOCK_MERCHANT_ID_FK` FOREIGN KEY (`merchant_id`) REFERENCES `merchant` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES ('AAA','Stock1',1,100,19,'2024-07-29 10:00:00.000',NULL,NULL,'2024-08-27 08:33:26.392','2024-08-28 09:41:15.214',1),('BBB','Stock2',2,200,20,'2024-07-29 10:00:00.000',NULL,NULL,'2024-08-27 08:33:26.392','2024-08-28 09:41:15.214',2);
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-02 12:15:20
