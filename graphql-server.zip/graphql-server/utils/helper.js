const { Buffer } = require("buffer");
const { parseISO, isValid, format } = require("date-fns");
const { parse: uuidParse, stringify: uuidStringify } = require("uuid");


function formatData(updatedItem, tableInfo) {
  for (const [key, attr] of Object.entries(tableInfo)) {
    if (Buffer.isBuffer(updatedItem[key]) && updatedItem[key].length === 16) {
      // Convert Buffer to UUID string
      updatedItem[key] = bufferToUUID(updatedItem[key]);
    }

    if (tableInfo[key].type == "INT") {
      updatedItem[key] = String(updatedItem[key]);
      console.log("Converted value of = ", updatedItem[key]);
    }

    if (tableInfo[key].type.includes("TIMESTAMP") || tableInfo[key].type.includes("DATETIME")) {
      const { isValid, formattedDate } = validateAndFormatDate(
        updatedItem[key]
      );
      if (isValid) {
        updatedItem[key] = formattedDate;
      }
    }
  }
  return updatedItem;
}

// Check if the value is a valid ISO 8601 string or a valid numeric timestamp
function validateAndFormatDate(value) {
  let isValidDate = false;
  let formattedDate = null;

  // Check if the value is a number (timestamp)
  if (!isNaN(value) && Number(value) >= 0) {
    // Convert timestamp to date and check validity
    const dateFromTimestamp = new Date(Number(value));
    isValidDate = !isNaN(dateFromTimestamp.getTime());
    if (isValidDate) {
      formattedDate = format(dateFromTimestamp, "yyyy-MM-dd HH:mm:ss");
    }
  }

  // Check if the value is a valid ISO 8601 string
  else {
    try {
      const dateFromISO = parseISO(value);
      isValidDate = isValid(dateFromISO);
      if (isValidDate) {
        formattedDate = format(dateFromISO, "yyyy-MM-dd HH:mm:ss");
      }
    } catch (error) {
      isValidDate = false;
    }
  }

  return {
    isValid: isValidDate,
    formattedDate: formattedDate,
  };
}

function uuidToBuffer(uuid, type){
  
  if (type.includes("BINARY")) {
    return Buffer.from(uuidParse(uuid)); 
  }

  return uuid;
}

function bufferToUUID(buffer) {
  if (Buffer.isBuffer(buffer) && buffer.length === 16) {
    return uuidStringify(buffer);
  } else {
    throw new Error("Buffer is not a valid UUID");
  }
}

module.exports = {
  formatData,
  validateAndFormatDate,
  uuidToBuffer,
  bufferToUUID
};
