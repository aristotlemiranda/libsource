const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
  'posdb',
  'graphqluser',
  'graphqluser@123',
  {
    host: '127.0.0.1',
    dialect: 'mysql'
  }
);

module.exports = sequelize;
