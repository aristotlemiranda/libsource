const { GraphQLScalarType, Kind } = require("graphql");

const Mixed = new GraphQLScalarType({
  name: "Mixed",
  description: "Custom scalar type for handling both String and Array",
  parseValue(value) {
    return value; // value from the client input variables
  },
  serialize(value) {
    return value; // value sent to the client
  },
  parseLiteral(ast) {
    switch (ast.kind) {
      case Kind.STRING:
        return ast.value;
      case Kind.LIST:
        return ast.values.map((v) => v.value);
      default:
        return null;
    }
  },
});

const typeDefinitions = `
    scalar Mixed

    type PageInfo {
      hasNextPage: Boolean!
      endCursor: String
    }
    
    input FilterInput {
      columnName: String
      value: Mixed
      operator: Operator!
    }

    input FilterQueryParamInput {
      where: CombinedFilterInput!
      rows: LimitInput
      sortBy: [OrderInput]
    }

    input CombinedFilterInput {
      and: [FilterInput]
      or: [FilterInput]
      
    }

    input LimitInput {
      limit: Int! = 100,
      offset: Int = 0
    }

    enum OrderDirection {
      ASC
      DESC
    }

    enum Operator {
      EQ
      NE
      GT
      GTE
      LT
      LTE
      LIKE
      BETWEEN
    }

    input OrderInput {
      column: String,
      order: OrderDirection!
    }

    input OptionsInput {
      rows:  LimitInput!,
      sortBy: [OrderInput]
    }
  `;

module.exports = typeDefinitions;
