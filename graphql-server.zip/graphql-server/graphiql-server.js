const express = require("express");
const { graphqlHTTP } = require("express-graphql");
const { buildSchema } = require("graphql");
const { Op } = require("sequelize");
const { ruruHTML } = require("ruru/server");
const { formatData, bufferToUUID, uuidToBuffer } = require("./utils/helper");
const { db } = require("./models/connection");
// Initialize Sequelize
const sequelize = db.sequelize;

const path = require('path');
const exclusion = require(path.join(__dirname, 'config', 'exclude-table.json'));

async function buildSchemaLocal() {
  const queryInterface = sequelize.getQueryInterface();
  const showAllTables = await queryInterface.showAllTables();

  const tables = showAllTables.filter(table => !exclusion.excludedTable.includes(table));
  
  console.log("Tables found in database:", tables);
  console.log("exclusion", exclusion.excludedTable);
  console.log("exclusion", exclusion.excludedFieldsInTable);


  let typeDefs = `
    type PageInfo {
      hasNextPage: Boolean!
      endCursor: String
    }
    
    input FilterInput {
      field: String
      value: String
      operator: String
    }

    input FilterQueryParamInput {
      where: CombinedFilterInput!
      limit: LimitInput
    }

    input CombinedFilterInput {
      and: [FilterInput]
      or: [FilterInput]
      
    }

    input LimitInput {
      limit: Int! = 100,
      offset: Int = 0
    }

    enum OrderDirection {
      ASC
      DESC
    }

    input OrderInput {
      column: String,
      order: OrderDirection!
    }

    input OptionsInput {
      rows:  LimitInput!,
      sortBy: [OrderInput]
    }
      
  `;
  let resolvers = {};

  for (const tableName of tables) {
    const tableInfo = await queryInterface.describeTable(tableName);

  
   // Convert the array to an object
  const excludedFieldsInTable = exclusion.excludedFieldsInTable.reduce((acc, item) => {
    const [key, value] = Object.entries(item)[0];
    acc[key] = value;
    return acc;
  }, {});



   console.log(`Defining schema for table: ${tableName}`, tableInfo);

    const fields = Object.entries(tableInfo)
      .filter(([key]) => {
        const excludedFields = excludedFieldsInTable[tableName] || [];
        return !excludedFields.includes(key);
      })
      .map(([key, attr]) => {
        let gqlType;
        switch (attr.type.toUpperCase()) {
          case "VARCHAR":
          case "TEXT":
            gqlType = "String";
            break;
          case "INT":
          case "TINYINT":
            gqlType = "Int";
            break;
          case "FLOAT":
          case "DOUBLE":
            gqlType = "Float";
            break;
          case "BOOLEAN":
            gqlType = "Boolean";
            break;
          case "DATE":
          case "DATETIME":
            gqlType = "String";
            break;
          case "BINARY":
            gqlType = "String"; // Use String for binary data, base64 encoded
            break;
          default:
            gqlType = "String";
        }
        return `${key}: ${gqlType}`;
      })
      .join("\n");

    typeDefs += `
      type ${tableName} {
        ${fields}
      }

      type ${tableName}Edge {
        node: ${tableName}
        cursor: String!
      }

      type ${tableName}Connection {
        edges: [${tableName}Edge]
        pageInfo: PageInfo!
      }
    `;

    resolvers[tableName.toLowerCase()] = async (args) => {
      console.log(`Fetching ${tableName.toLowerCase()} with args:`, args);
      try {
        const model = sequelize.define(tableName, tableInfo, {
          tableName,
          timestamps: false,
          modelName: tableName,
        });

        // Convert UUID string from args to Buffer for querying
        const queryId = uuidToBuffer(args.id, tableInfo.id.type);

        const result = await model.findByPk(queryId);

        // Convert binary fields to UUID strings
        const updatedResults = result;
        let updatedItem = updatedResults.dataValues; // Create a copy to modify
        updatedItem = formatData(updatedItem, tableInfo);
        console.log(`Result for ${tableName.toLowerCase()}:`, updatedResults);
        return updatedResults;
      } catch (error) {
        console.error(`Error fetching ${tableName.toLowerCase()}:`, error);
        throw new Error(`Failed to fetch ${tableName.toLowerCase()}`);
      }
    };

    resolvers[`${tableName.toLowerCase()}s`] = async ({
      after,
      first = 10,
    }) => {
      console.log(`Fetching paginated ${tableName.toLowerCase()}s`);

      try {
        const model = sequelize.define(tableName, tableInfo, {
          tableName,
          timestamps: false,
          modelName: tableName,
        });

        const queryOptions = {
          limit: first,
          order: [["id", "ASC"]], // Ensure ordering
          where: {},
        };

        if (after) {
          const afterId = bufferToUUID(Buffer.from(after, "base64"));
          queryOptions.where.id = { [Op.gt]: afterId };
        }

        const result = await model.findAndCountAll(queryOptions);
        const items = result.rows;

        const edges = items.map((item) => {
          let itemData = item.dataValues;

          itemData = formatData(itemData, tableInfo);

          console.log("ItemData ID:", itemData.id);

          return {
            node: itemData,
            cursor: uuidToBuffer(itemData.id, tableInfo.id.type).toString(
              "base64"
            ),
          };
        });

        console.log("debug id=", items[items.length - 1].id);

        const hasNextPage = result.count > first;
        const endCursor = hasNextPage
          ? uuidToBuffer(
              items[items.length - 1].id,
              tableInfo.id.type
            ).toString("base64")
          : null;
        //const endCursor = hasNextPage ? Buffer.from(uuidToBuffer(items[items.length - 1].id)).toString('base64') : null;

        return {
          edges,
          pageInfo: {
            hasNextPage,
            endCursor,
          },
        };
      } catch (error) {
        console.error(
          `Error fetching paginated ${tableName.toLowerCase()}s:`,
          error
        );
        throw new Error(
          `Failed to fetch paginated ${tableName.toLowerCase()}s`
        );
      }
    };

    resolvers[`fetchAll_${tableName.toLowerCase()}s`] = async (paginate) => {
      console.log(`Fetching all ${tableName.toLowerCase()}s`);
      try {
        const model = sequelize.define(tableName, tableInfo, {
          tableName,
          timestamps: false,
          modelName: tableName,
        });
        const opt = paginate.paginate;
        let orderClauses;
        let queryOptions;
        
        if(opt) {
          orderClauses =
          opt && opt.sortBy && opt.sortBy.length > 0
            ? opt.sortBy.map((sortOption) => [
                sortOption.column,
                sortOption.order,
              ])
            : undefined;

            queryOptions = {
              limit: opt.rows.limit,
              offset: opt.rows.offset,
              where: {},
              ...(orderClauses && { order: orderClauses }), // Conditionally add the order property
            };
        }else {
          queryOptions = {
            limit: 100,
            offset: 0,
            where: {},
            ...(orderClauses && { order: orderClauses }), // Conditionally add the order property
          };
        }

       
        

        const result = await model.findAll({
          ...queryOptions,
        });

        // Convert binary fields to UUID strings
        const updatedResults = result.map((item) => {
          let updatedItem = { ...item.dataValues }; // Create a copy to modify
          updatedItem = formatData(updatedItem, tableInfo);
          return updatedItem;
        });

        console.log(
          `Result for all ${tableName.toLowerCase()}s:`,
          updatedResults
        );
        return updatedResults;
      } catch (error) {
        console.error(`Error fetching all ${tableName.toLowerCase()}s:`, error);
        throw new Error(`Failed to fetch all ${tableName.toLowerCase()}s`);
      }
    };

    resolvers[`filter_${tableName.toLowerCase()}`] = async ({ criteria }) => {
      console.log(
        `Fetching ${tableName.toLowerCase()}s with filter:`,
        criteria
      );

      try {
        const model = sequelize.define(tableName, tableInfo, {
          tableName,
          timestamps: false,
          modelName: tableName,
        });

        // Build the dynamic where clause
        primaryKey = model.primaryKeyAttribute;
        const buildWhereClause = (criteria) => {
          if (!criteria) return {};

          // Define a mapping for filter operators to Sequelize operators
          const operatorMap = {
            eq: Op.eq, // Equal
            ne: Op.ne, // Not equal
            gt: Op.gt, // Greater than
            gte: Op.gte, // Greater than or equal
            lt: Op.lt, // Less than
            lte: Op.lte, // Less than or equal
            like: Op.like, //Like
            contains: Op.contains, //contains
            // Add more operators if needed
          };

          let whereClause = {};

          // Handle 'and' conditions
          if (criteria.where.and) {
            whereClause[Op.and] = criteria.where.and.map((f) => ({
              [f.field]: {
                [operatorMap[f.operator] || Op.eq]: f.value,
              },
            }));
          }

          // Handle 'or' conditions
          if (criteria.where.or) {
            whereClause[Op.or] = criteria.where.or.map((f) => ({
              [f.field]: {
                [operatorMap[f.operator] || Op.eq]: f.value,
              },
            }));
          }

          return whereClause;
        };

        const queryOptions = {
          limit: criteria.limit.limit,
          offset: criteria.limit.offset,
          order: [[primaryKey, "ASC"]],
          where: buildWhereClause(criteria),
        };

        const result = await model.findAndCountAll(queryOptions);

        if (result.count == 1) {
          let updatedItem = result.rows[0].dataValues;
          updatedItem = formatData(updatedItem, tableInfo);
          return new Array(updatedItem);
        } else {
          // Convert binary fields to UUID strings
          const updatedResults = result.rows.map((item) => {
            let updatedItem = { ...item.dataValues }; // Create a copy to modify
            updatedItem = formatData(updatedItem, tableInfo);
            return updatedItem;
          });
          console.log(
            `Result for all ${tableName.toLowerCase()}s:`,
            updatedResults
          );
          return updatedResults;
        }
      } catch (error) {
        console.error(
          `Error fetching paginated filter_${tableName.toLowerCase()}:`,
          error
        );
        throw new Error(
          `Failed to fetch paginated ${tableName.toLowerCase()}s`
        );
      }
    };
  }

  typeDefs += `
    type Query {
      ${tables
        .map(
          (tableName) => `
        ${tableName.toLowerCase()}(id: String): ${tableName}
        ${tableName.toLowerCase()}s(after: String, first: Int): ${tableName}Connection
        fetchAll_${tableName.toLowerCase()}s (paginate: OptionsInput): [${tableName}]
        filter_${tableName.toLowerCase()}(criteria: FilterQueryParamInput!): [${tableName}]
      `
        )
        .join("\n")}
    }
  `;

  console.log("Generated typeDefs:", typeDefs);
  console.log("Resolvers:", resolvers);

  const schema = buildSchema(typeDefs);

  return {
    schema,
    rootValue: {
      ...resolvers,
    },
  };
}

async function startServer() {
  const { schema, rootValue } = await buildSchemaLocal();

  const app = express();

  app.use(
    "/graphql",
    graphqlHTTP({
      schema,
      rootValue,
      graphiql: false,
    })
  );

  // Serve the Ruru GraphiQL IDE
  app.get("/graphql-server", (_req, res) => {
    res.type("html");
    res.end(ruruHTML({ endpoint: "/graphql" }));
  });

  app.listen(4000, () => {
    console.log("🚀 Server ready at http://localhost:4000/graphql-server");
  });
}


startServer();
