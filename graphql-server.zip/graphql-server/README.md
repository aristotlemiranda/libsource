# GraphQL Sample Queries

## Filter merchant by id
{
  merchant(id: "e7d65f9a-3118-11ef-bee3-0242ac110002") {
    id
    merchant_name
  }
  inv_mgmt_items {
    edges {
      node {
        sku
        item_name
        id
        merchant_id
      }
    }
  }
}

## Filter merchant by field merchant_name
query {
  filter_merchant(filter: {
    or: [
      {
        field: "merchant_name",
        value: "SavoryGO",
        operator: "eq"
      },
      {
        field: "account_id",
        value: "001NPOS24",
        operator: "eq"
      }
    ]
    
  }) {
    merchant_name
    account_id
    created_date
    modified_date
  }
}

## Filter by columns
### operator: eq, gt, lt, lte, gte
query {
  filter_simple(filter: {
    and: [
      {
        field: "name",
        value: "Banana",
        operator: "eq"
      },
      {
        field: "amount",
        value: "10",
        operator: "gte"
      }
    ]
    
  }) {
   id
   name
   amount
  }
}

## Using Operator Map
query {
  filter_simple(filter: {
    or: [
      {
        field: "amount",
        value: "20",
        operator: "lte"
      }
    ]
    
  }) {
   id
   name
  }
}

## Fetch all merchants
query fetchAll_merchants {
  fetchAll_merchants {
    id
    merchant_name
    created_date
    modified_date
  }
}

## Fetch all merchants with all its categories
query fetchAll_merchants {
  fetchAll_merchants {
    id
    merchant_name
    created_date
    modified_date
  }
  inv_mgmt_categorys {
    edges {
      node {
        id
        category_name
        merchant_id
        created_date
        modified_date
      }
    }
  }
}

# Advance Query
## Using cursor
query {
  merchants(after:"8dVI5zEYEe++4wJCrBEAAg==") {
    edges {
      node {
        id
        merchant_name
      }
      cursor
    }
    pageInfo {
      hasNextPage
      endCursor
    }
  }
}

query {
  merchants(after:"8dVI5zEYEe++4wJCrBEAAg==", first: 2) {
    edges {
      node {
        id
        merchant_name
      }
      cursor
    }
    pageInfo {
      hasNextPage
      endCursor
    }
  }
}


## Sample
query SampleQuery {
	fetchAll_merchants {
    id
    merchant_name
    created_date
  }
  
  merchant(id: "bd5304b9-d520-42c3-848d-65bc4dca82ac") {
    id
    merchant_name
  }
  
  merchants {
    edges {
      node {
        id
        merchant_name
        created_date
      }
    }
  }
  
  filter_merchant(filter: {
    and: {
      field: "merchant_name",
      value: "IceIceBaby"
      operator: "eq"
    }
  }) {
    id
    merchant_name
    account_id
    modified_date
  }
}

# Order, Limit and Offset
query OrderBy {
  fetchAll_work_logs(
    options: {
      rows: { limit: 1000, offset: 0 }
    	#sortBy: [{ column: "id", order: DESC }, { column: "task_name", order: ASC }] 
      sortBy: [{ column: "id", order: DESC }] 
    }
  ) {
    id
    modified_date
    task_name
  }
}
