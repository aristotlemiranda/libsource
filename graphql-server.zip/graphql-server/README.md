# GraphQL Sample Queries
## Fetch All Merchants
### SQL equivalent: SELECT `id`, `merchant_name`, `account_id`, `created_date`, `modified_date` FROM `merchant` AS `merchant` LIMIT 0, 100;

query SampleQuery {
  fetchAll_merchants {
    id
    created_date
    modified_date
  }
}

## Fetch All with Row Limits and SortBy
### SQL equivalent: SELECT `id`, `category_name`, `merchant_id`, `description`, `arrangement`, `created_date`, `modified_date` FROM `inv_mgmt_category` AS `inv_mgmt_category` ORDER BY `inv_mgmt_category`.`arrangement` ASC LIMIT 0, 10;

query Jobs {
  fetchAll_inv_mgmt_categorys(
    paginate: {
      rows: { limit: 10, offset: 0 }
      sortBy: { order: ASC, column: "arrangement" }
    }
  ) {
    arrangement
    created_date
    description
    merchant_id
    id
    modified_date
  }
}


## Fetch Merchant By ID
### SQL equivalent: SELECT `id`, `merchant_name`, `account_id`, `created_date`, `modified_date` FROM `merchant` AS `merchant` WHERE `merchant`.`id` = X'01cdf6c1deff4f9a9cfbbff9c229886b';

query SampleQuery {
  merchant(id: "01cdf6c1-deff-4f9a-9cfb-bff9c229886b") {
    id
    created_date
    modified_date
  }
}

## Filter By Columns
### SQL equivalent: SELECT `JOB_EXECUTION_ID`, `STATUS`, `CREATED_DATE`, `EXIT_CODE` FROM `BATCH_JOB_EXECUTION` AS `BATCH_JOB_EXECUTION` WHERE (`BATCH_JOB_EXECUTION`.`JOB_EXECUTION_ID` = '1' AND `BATCH_JOB_EXECUTION`.`STATUS` = 'COMPLETED') ORDER BY `BATCH_JOB_EXECUTION`.`JOB_EXECUTION_ID` ASC LIMIT 0, 100;

query Jobs {
  filter_batch_job_execution(
    criteria: {
      where: {
        and: [
          { operator: EQ, columnName: "JOB_EXECUTION_ID", value: "1" },
          { operator: EQ, columnName: "STATUS", value: "COMPLETED" }
        ]
      }
    }
  ) {
    JOB_EXECUTION_ID
    STATUS
    CREATED_DATE
  }
}

## Filter by date between
## SQL equivalent: SELECT `JOB_EXECUTION_ID`, `STATUS`, `CREATED_DATE`, `EXIT_CODE` FROM `BATCH_JOB_EXECUTION` AS `BATCH_JOB_EXECUTION` WHERE (`BATCH_JOB_EXECUTION`.`CREATED_DATE` BETWEEN '2024-09-09 08:00:00' AND '2024-09-09 11:00:00') ORDER BY `BATCH_JOB_EXECUTION`.`JOB_EXECUTION_ID` ASC LIMIT 0, 100;

query Jobs {
  filter_batch_job_execution(
    criteria: {
      where: {
        and: {
          operator: BETWEEN
          columnName: "CREATED_DATE"
          value: ["2024-09-09 08:00:00", "2024-09-09 11:00:00"]
        }
      }
    }
  ) {
    JOB_EXECUTION_ID
    STATUS
    CREATED_DATE
  }
}

## Filter with SortBy and Row Limits
### SQL equivalent: SELECT `JOB_EXECUTION_ID`, `STATUS`, `CREATED_DATE`, `EXIT_CODE` FROM `BATCH_JOB_EXECUTION` AS `BATCH_JOB_EXECUTION` WHERE (`BATCH_JOB_EXECUTION`.`STATUS` != 'ABORTED') ORDER BY `BATCH_JOB_EXECUTION`.`JOB_EXECUTION_ID` DESC LIMIT 0, 10;

query Jobs {
  filter_batch_job_execution(
    criteria: {
      where: { and: { operator: NE, columnName: "STATUS", value: "ABORTED" } }
      rows: { limit: 10, offset: 0 }
      sortBy: { order: DESC, column: "JOB_EXECUTION_ID" }
    }
  ) {
    JOB_EXECUTION_ID
    STATUS
    CREATED_DATE
  }
}


# Configuration
## Database connection configuration
### Under "config" folder edit config.json for connection and database properties. Similaryly, .env can also be exposed for Production use.

## Excluding tables
### To exclude table edit /config/exclude-table.json
### e.g. Excluding work_log, promotion, stock tables. See `excludedTable`

    {
        "excludedTable": [
          "work_log", "promotion", "stock"
        ],
        "excludedFieldsInTable": [
            {"merchant": [ "account_id", "merchant_name"]},
            {"inv_mgmt_category": [ "category_name", "field2"]}
        ]
    }

### You can also exlude fields/columns in the the table under `excludedFieldsInTable`.