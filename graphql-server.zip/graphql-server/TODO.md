# TODO: Raise on 29/8/2024
## Status: Completed
1. filter_ function bug when id is selected. - Fix on 30/8/2024
2. filter_ function bug when column value is int - Fix on 30/8/2024
3. fetchAll when bug when column value is int - Fix on 30/8/2024

# TODO: Raise 30/8/2024
## Status: Open
1. Data format for other column type for the Date variance. - Fix on 6/9/2024
2. To test for any possible breakage. - Done on 6/9/2024
3. To add like - operator for the where close.
4. To add functionality to mix or and and in the where clause.
5. To put limit of 100 by default. - Fix on 6/9/2024
6. Pass argument limit. - Fix on 6/9/2024
7. Pass argument between for date.

